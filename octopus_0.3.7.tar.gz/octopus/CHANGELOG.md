# Changelog
All notable changes to this project will be documented in this file.


## [0.3.7] - 2018-10-12
### Added
- support multiple referencing files.
- support windows now.

### Changed

### Removed


